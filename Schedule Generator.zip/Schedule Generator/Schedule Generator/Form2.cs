﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;

namespace Schedule_Generator
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void saveAS_Click(object sender, EventArgs e)
        {
            /*
            Form3 form3 = new Form3();
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Save File";
            save.Filter = "JPG Files  (*.jpg)|";

            if (save.ShowDialog() == DialogResult.OK)
            {
                StreamWriter write = new StreamWriter(File.Create(save.FileName));

                write.Write(form3.richTextBox1.Text);
                save.Dispose();
            }
             */
        }

        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
            Form3 form3 = new Form3();
            OpenFileDialog open = new OpenFileDialog();
            if (open.ShowDialog() == DialogResult.OK)
            {
                StreamReader read = new StreamReader(File.OpenRead(open.FileName));

                form3.richTextBox1.Text = read.ReadToEnd();
                read.Dispose();
            }

            form3.ShowDialog();
             */
        }

        Bitmap bitmap; Graphics graphics; ImageFormat img;
        private void takeSnapShotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bitmap = new Bitmap(Form2.ActiveForm.Size.Width, Form2.ActiveForm.Size.Height);
            graphics = Graphics.FromImage(bitmap);
            graphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, Form2.ActiveForm.Size);

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                switch (saveFileDialog1.FilterIndex)
                {
                    case 0: img = ImageFormat.Bmp; break;
                    case 1: img = ImageFormat.Png; break;
                    case 2: img = ImageFormat.Jpeg; break;  
                }
                bitmap.Save(saveFileDialog1.FileName, img);
                this.Show();
            }
        }
    }
}
