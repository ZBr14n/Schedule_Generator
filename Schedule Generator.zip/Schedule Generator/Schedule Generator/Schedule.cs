﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Schedule_Generator
{
    class Schedule
    {
        public static bool determineCORRECTtime(int[] theHour, string[] ampm) {
            
            for (int i = 0, j = 0; i < theHour.Length && j < ampm.Length; i++, j++) {
                if (ampm[j] == "A.M.") {  //A.M. < P.M.
                    return false;
                }
                else if (ampm[j] == "P.M.") {   //P.M. > A.M.
                    return true;
                }
            }
            return false;
        }

        public static bool checkValidTimeEntry2(Schedule class1, Schedule class2)
        {
            int count = 1;
            for (int a = 0; a <= 12; a++)
            {
                if (new[] { class1.getFromHour(), class2.getFromHour() }.All(x => x == count))
                {
                    return true;
                }
                count++;
            }
            return false;
        }

        public static bool checkValidTimeEntry(int frmHR, int frmMN, int toHR, int toMN)
        {
            string FROMHR = Convert.ToString(frmHR);
            string FROMMN = Convert.ToString(frmMN);
            string FROM = FROMHR + FROMMN;

            string TOHR = Convert.ToString(toHR);
            string TOMN = Convert.ToString(toMN);
            string TO = TOHR + TOMN;

            int parsedFROM = int.Parse(FROM);
            int parsedTO = int.Parse(TO);

            if (parsedFROM > parsedTO) {
                return true;
            }
            return false;
        }

        public static string getSubString(string theDay)
        {
            return theDay.Substring(0, theDay.Length);         
        }

        //prints out user input.
        public string printSchedule(string theClass,int frmHR,int frmMN,
                                    int toHR,int toMN,string theAMPM,
                                    string thelocation){
 
           if ((frmMN == 0 || frmMN == 5) && (toMN == 0 || toMN == 5))
           {
                     return (theClass + Environment.NewLine +
                     frmHR + " : " + "0" + frmMN + " - " + toHR + " : " + "0" + toMN + " " + theAMPM +
                     Environment.NewLine + thelocation + Environment.NewLine + Environment.NewLine);
           }

            if ((frmMN == 0 || frmMN == 5) && (toMN != 0 || toMN != 5)) 
            {
                return (theClass + Environment.NewLine +
                frmHR + " : " + "0" + frmMN + " - " + toHR + " : " +  toMN + " " + theAMPM +
                Environment.NewLine + thelocation + Environment.NewLine + Environment.NewLine);
            }
            else if ((frmMN != 0 || frmMN != 5) && (toMN == 0 || toMN == 5)) {
                return (theClass + Environment.NewLine +
                frmHR + " : " + frmMN + " - " + toHR + " : " + "0" + toMN + " " + theAMPM +
                Environment.NewLine + thelocation + Environment.NewLine + Environment.NewLine);
            }
                  
              //regular return
              return(theClass + Environment.NewLine +
                     frmHR + " : " + frmMN + " - " + toHR + " : " + toMN + " " + theAMPM + 
                     Environment.NewLine + thelocation + Environment.NewLine + Environment.NewLine);   
        }

        //matches correct days according to user input.
        public string populateSchedule(string lengthOfDay) {
       
            string matchLength = lengthOfDay;
            for (int i = 0; i < lengthOfDay.Length; i++)
            { 
                matchLength = lengthOfDay.Substring(0, lengthOfDay.Length);
                switch (matchLength[i])
                {
                    case 'M':
                    case 'm':
                        return printSchedule(getClassName(), getFromHour(), getFromMin(), getToHour(), getToMin(), getAMPM(), getLocation());
                    case 'T':
                    case 't':
                        return printSchedule(getClassName(), getFromHour(), getFromMin(), getToHour(), getToMin(), getAMPM(), getLocation()); 
                    case 'W':
                    case 'w':
                        return printSchedule(getClassName(), getFromHour(), getFromMin(), getToHour(), getToMin(), getAMPM(), getLocation()); 
                    case 'R':
                    case 'r':
                        return printSchedule(getClassName(), getFromHour(), getFromMin(), getToHour(), getToMin(), getAMPM(), getLocation()); 
                    case 'F':
                    case 'f':
                        return printSchedule(getClassName(), getFromHour(), getFromMin(), getToHour(), getToMin(), getAMPM(), getLocation()); 
                }
            }
            
            return null;
        }

        private string className;
        private int FromHour;
        private int FromMin;
        private int ToHour;
        private int ToMin;
        private string ampm;
        private string day;
        private string location;

        public Schedule()
        {
            className = "";
            FromHour = 0;
            FromMin = 0;
            ToHour = 0;
            ToMin = 0;
            ampm = "";
            day = "";
            location = "";
        }

        public Schedule(string newClass, int newFromHR, int newFromMin, int newToHR, int newToMin,
                 string newAMPM, string newDay, string newLocation) {

           className = newClass; FromHour = newFromHR; FromMin = newFromMin;
           ToHour = newToHR; ToMin = newToMin; ampm = newAMPM; day = newDay; location = newLocation;
        }

        public string getClassName() { return className; }
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/

        public int getFromHour() { return FromHour; }

        public int getFromMin() { return FromMin; }

        public int getToHour() { return ToHour; }

        public int getToMin() { return ToMin; }

        public string getAMPM() { return ampm; }

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/
        public string getDay() { return day; }
        public string getLocation() { return location; }

        public void setClassName(string theClass) { className = theClass; }
        public void setFromHour(int theHour) { FromHour = theHour; }
        public void setFromMin(int theMin) { FromMin = theMin; }
        public void setToHour(int theHour) { ToHour = theHour; }
        public void setToMin(int theMin) { ToMin = theMin; }
        public void setAMPM(string theAMPM) { ampm = theAMPM; }
        public void setDay(string theDay) { day = theDay; }
        public void setLocation(string theLocation) { location = theLocation; }


    }
}
