﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Schedule_Generator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textClass.Text == "" || textClass2.Text == "" || textClass3.Text == "" || textClass4.Text == "" ||
               fromHour.Text == "" || fromHour2.Text == "" || fromHour3.Text == "" || fromHour4.Text == "" ||
               toHour.Text == "" || toHour2.Text == "" || toHour3.Text == "" || toHour4.Text == "" ||
               textDay.Text == "" || textDay2.Text == "" || textDay3.Text == "" || textDay4.Text == "") 
            {
                MessageBox.Show("Fields cannot be left blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {                                                                                                   
                Form2 form2 = new Form2();
                /********************classObject1*****************************************/
                string txtclass = textClass.Text;
                int fromHR = Convert.ToInt32(fromHour.Text);
                int fromMN = Convert.ToInt32(fromMin.Text);
                int toHR = Convert.ToInt32(toHour.Text);
                int toMN = Convert.ToInt32(toMin.Text);
                string theAMPM = ampm.Text;
                string theDay = Schedule.getSubString(textDay.Text);
                string theWhere = textPlace.Text;
                /*************************classObject2*************************************/
                string txtclass2 = textClass2.Text;
                int fromHR2 = Convert.ToInt32(fromHour2.Text);
                int fromMN2 = Convert.ToInt32(fromMin2.Text);
                int toHR2 = Convert.ToInt32(toHour2.Text);
                int toMN2 = Convert.ToInt32(toMin2.Text);
                string theAMPM2 = ampm2.Text;
                string theDay2 = Schedule.getSubString(textDay2.Text);
                string theWhere2 = textPlace2.Text;
         //************************classObject3**************************************************
                string txtclass3 = textClass3.Text;
                int fromHR3 = Convert.ToInt32(fromHour3.Text);
                int fromMN3 = Convert.ToInt32(fromMin3.Text);
                int toHR3 = Convert.ToInt32(toHour3.Text);
                int toMN3 = Convert.ToInt32(toMin3.Text);
                string theAMPM3 = ampm3.Text;
                string theDay3 = Schedule.getSubString(textDay3.Text);
                string theWhere3 = textPlace3.Text;
      //************************classObject4************************************************
                string txtclass4 = textClass4.Text;
                int fromHR4 = Convert.ToInt32(fromHour4.Text);
                int fromMN4 = Convert.ToInt32(fromMin4.Text);
                int toHR4 = Convert.ToInt32(toHour4.Text);
                int toMN4 = Convert.ToInt32(toMin4.Text);
                string theAMPM4 = ampm4.Text;
                string theDay4 = Schedule.getSubString(textDay4.Text);
                string theWhere4 = textPlace4.Text;                     
     //**************************************************************************************
                
                Schedule class1 = new Schedule(txtclass, fromHR, fromMN, toHR,
                                               toMN, theAMPM, theDay, theWhere);

                Schedule class2 = new Schedule(txtclass2, fromHR2, fromMN2, toHR2,
                                               toMN2, theAMPM2, theDay2, theWhere2);
                                                                                              
                Schedule class3 = new Schedule(txtclass3, fromHR3, fromMN3, toHR3,
                                               toMN3, theAMPM3, theDay3, theWhere3);
                         
                Schedule class4 = new Schedule(txtclass4, fromHR4, fromMN4, toHR4,
                                               toMN4, theAMPM4, theDay4, theWhere4);
                             
    
               int[] timeBox = new int[] { class1.getFromHour(), class2.getFromHour(), class3.getFromHour(), class4.getFromHour() };
               string[] storeAMPM = new string[] { class1.getAMPM(), class2.getAMPM(), class3.getAMPM(), class4.getAMPM() };
       /*            
               var duplicateGroups =            //detects duplicate AMPMs
               (from string item in storeAMPM select item).GroupBy(s => s).Select(
               group => new { Word = group.Key, Count = group.Count() }).Where(x => x.Count >= 2);

               for (int a = 0; a < duplicateGroups.ToString().Length; a++) {
                   if (duplicateGroups.ToString() == "A.M." && duplicateGroups.ToString() == "P.M.")
                   {
                       Array.Sort(duplicateGroups.ToArray(), timeBox);
                   }                  
               }
        */
               var duplicates = storeAMPM.GroupBy(g => g).Where(w => w.Count() > 1).Select(s => s.Key);
               Array.Sort(storeAMPM,timeBox);

               form2.label6.Text = Convert.ToString(timeBox[0]); form2.label10.Text = storeAMPM[0];
               form2.label7.Text = Convert.ToString(timeBox[1]); form2.label11.Text = storeAMPM[1];
               form2.label8.Text = Convert.ToString(timeBox[2]); form2.label12.Text = storeAMPM[2];
               form2.label9.Text = Convert.ToString(timeBox[3]); form2.label13.Text = storeAMPM[3];

               if (form2.label10.Text == storeAMPM[0])
               {
                   form2.label6.Text = Convert.ToString(timeBox[0]);
               }
               else if (form2.label11.Text == storeAMPM[1])
               {
                   form2.label7.Text = Convert.ToString(timeBox[1]);
               }
               else if (form2.label12.Text == storeAMPM[2])
               {
                   form2.label8.Text = Convert.ToString(timeBox[2]);
               }
               else if (form2.label13.Text == storeAMPM[3])
               {
                   form2.label9.Text = Convert.ToString(timeBox[3]);
               }

                //if true, time entry invalid.   start time > end time
                if ((Schedule.checkValidTimeEntry(fromHR, fromMN, toHR, toMN) == true) ||
                    (Schedule.checkValidTimeEntry(fromHR2, fromMN2, toHR2, toMN2) == true) ||
                    (Schedule.checkValidTimeEntry2(class1, class2)) == true)
                {
                    MessageBox.Show("Invalid Time Entry(s).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    form2.Hide();
                    this.Show();
                }
                //if false, start time < end time then check if Hours are same for all class obj.
                else if ((Schedule.checkValidTimeEntry(fromHR, fromMN, toHR, toMN) == false) ||
                         (Schedule.checkValidTimeEntry(fromHR2, fromMN2, toHR2, toMN2) == false) ||
                          Schedule.checkValidTimeEntry2(class1, class2) == false)
                {
                    if (theDay.Length != theDay2.Length || theDay2.Length != theDay3.Length || 
                        theDay3.Length != theDay4.Length || theDay4.Length != theDay.Length)
                    {
                        for (int s = 0; s < theDay.Length; s++)
                        {
                            switch (theDay[s])
                            {
                                case 'M':     
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox1.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox11.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour())) 
                                    {
                                        form2.textBox111.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox2.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox22.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox222.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox3.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox33.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox333.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox4.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox44.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox444.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox5.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox55.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox555.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                            }
                        }

                        for (int f = 0; f < theDay2.Length; f++)
                        {
                            switch (theDay2[f])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox1.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox11.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox111.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox2.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox22.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox222.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox3.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox33.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox333.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox4.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox44.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox444.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox5.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox55.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox555.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                            }
                        }

                        for (int f = 0; f < theDay3.Length; f++)
                        {
                            switch (theDay3[f])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox1.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox11.Text += class3.populateSchedule(theDay3);
                                    }
                                    if(form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox111.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox2.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox22.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox222.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox3.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox33.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox333.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox4.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox44.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox444.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox5.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox55.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox555.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                            }
                        }

                        for (int f = 0; f < theDay4.Length; f++)
                        {
                            switch (theDay4[f])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox1.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox11.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox111.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox2.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox22.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox222.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox3.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox33.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox333.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox4.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox44.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox444.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox5.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox55.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox555.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                            }
                        }
                    }

                    else if (theDay.Length == theDay2.Length || theDay2.Length == theDay3.Length ||
                             theDay3.Length == theDay4.Length || theDay4.Length == theDay.Length) //equals
                    {
                        for (int a = 0, b = 0 , c = 0, d = 0; 
                             a < theDay.Length && b < theDay2.Length && c < theDay3.Length && d < theDay4.Length; 
                             a++, b++, c++, d++)
                        {
                            switch (theDay[a])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox1.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox11.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox111.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox2.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox22.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox222.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox3.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox33.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox333.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox4.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox44.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox444.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox5.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox55.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox555.Text += class1.populateSchedule(theDay);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class1.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class1.populateSchedule(theDay);
                                    }
                                    break;
                            }

                            switch (theDay2[b])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox1.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox11.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox111.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox2.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox22.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox222.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox3.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox33.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox333.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox4.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox44.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox444.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox5.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox55.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox555.Text += class2.populateSchedule(theDay2);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class2.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class2.populateSchedule(theDay2);
                                    }
                                    break;
                            }

                            switch (theDay3[c])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox1.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox11.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox111.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox2.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox22.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox222.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox3.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox33.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox333.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox4.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox44.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox444.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox5.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox55.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox555.Text += class3.populateSchedule(theDay3);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class3.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class3.populateSchedule(theDay3);
                                    }
                                    break;
                            }

                            switch (theDay4[c])
                            {
                                case 'M':
                                case 'm':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox1.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox11.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox111.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox1111.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'T':
                                case 't':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox2.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox22.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox222.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox2222.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'W':
                                case 'w':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox3.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox33.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox333.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox3333.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'R':
                                case 'r':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox4.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox44.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox444.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox4444.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                                case 'F':
                                case 'f':
                                    if (form2.label6.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox5.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label7.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox55.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label8.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox555.Text += class4.populateSchedule(theDay4);
                                    }
                                    if (form2.label9.Text == Convert.ToString(class4.getFromHour()))
                                    {
                                        form2.textBox5555.Text += class4.populateSchedule(theDay4);
                                    }
                                    break;
                            }
                        }                        
                    }
                    form2.ShowDialog();
                }
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void textClass_MouseClick(object sender, MouseEventArgs e)
        {
          
        }

        private void textClass_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textClass_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void fillDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textClass.Text = "Art";
            textClass2.Text = "Music";
            textClass3.Text = "Bio";
            textClass4.Text = "Chem";
            /////////////////////////
            fromHour.Text = "1";            
            fromHour2.Text = "6";
            fromHour3.Text = "3";
            fromHour4.Text = "11";

            fromMin.Text = "00";
            fromMin2.Text = "00";
            fromMin3.Text = "00";
            fromMin4.Text = "00";
            //////////////////////
            toHour.Text = "2";
            toHour2.Text = "7";
            toHour3.Text = "4";
            toHour4.Text = "11";

            toMin.Text = "00";
            toMin2.Text = "00";
            toMin3.Text = "00";
            toMin4.Text = "30";
            /////////////////////////
            ampm.Text = "A.M.";
            ampm2.Text = "A.M.";
            ampm3.Text = "P.M.";
            ampm4.Text = "P.M.";
            /////////////////////////
            textDay.Text = "MTW";
            textDay2.Text = "TWR";
            textDay3.Text = "MF";
            textDay4.Text = "TR";
            //////////////////////////
            textPlace.Text = "Watson";
            textPlace2.Text = "Dobbs";
            textPlace3.Text = "Kingman";
            textPlace4.Text = "Beatty";
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyMessageBoxForm3 MyMSGBox = new MyMessageBoxForm3();

            MyMSGBox.textBox1.Text = Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine + "This program is intended to make class registration preparation more easier. Use this program to test if whether you like the classes you have chosen before commiting to it during course registration."; 

            MyMSGBox.ShowDialog();
        }
        
    }
}
