﻿namespace Schedule_Generator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textClass = new System.Windows.Forms.TextBox();
            this.textDay = new System.Windows.Forms.TextBox();
            this.textPlace = new System.Windows.Forms.TextBox();
            this.fromHour = new System.Windows.Forms.ComboBox();
            this.fromMin = new System.Windows.Forms.ComboBox();
            this.toHour = new System.Windows.Forms.ComboBox();
            this.toMin = new System.Windows.Forms.ComboBox();
            this.ampm = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ampm2 = new System.Windows.Forms.ComboBox();
            this.toMin2 = new System.Windows.Forms.ComboBox();
            this.toHour2 = new System.Windows.Forms.ComboBox();
            this.fromMin2 = new System.Windows.Forms.ComboBox();
            this.fromHour2 = new System.Windows.Forms.ComboBox();
            this.textPlace2 = new System.Windows.Forms.TextBox();
            this.textDay2 = new System.Windows.Forms.TextBox();
            this.textClass2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ampm3 = new System.Windows.Forms.ComboBox();
            this.toMin3 = new System.Windows.Forms.ComboBox();
            this.toHour3 = new System.Windows.Forms.ComboBox();
            this.fromMin3 = new System.Windows.Forms.ComboBox();
            this.fromHour3 = new System.Windows.Forms.ComboBox();
            this.textPlace3 = new System.Windows.Forms.TextBox();
            this.textDay3 = new System.Windows.Forms.TextBox();
            this.textClass3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.ampm4 = new System.Windows.Forms.ComboBox();
            this.toMin4 = new System.Windows.Forms.ComboBox();
            this.toHour4 = new System.Windows.Forms.ComboBox();
            this.fromMin4 = new System.Windows.Forms.ComboBox();
            this.fromHour4 = new System.Windows.Forms.ComboBox();
            this.textPlace4 = new System.Windows.Forms.TextBox();
            this.textDay4 = new System.Windows.Forms.TextBox();
            this.textClass4 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fillDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Class Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(236, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "From";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(398, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "To";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(501, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "A.M./P.M.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(658, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Day";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(792, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Where";
            // 
            // textClass
            // 
            this.textClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textClass.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textClass.Location = new System.Drawing.Point(23, 113);
            this.textClass.Name = "textClass";
            this.textClass.Size = new System.Drawing.Size(123, 20);
            this.textClass.TabIndex = 1;
            // 
            // textDay
            // 
            this.textDay.Location = new System.Drawing.Point(627, 113);
            this.textDay.Name = "textDay";
            this.textDay.Size = new System.Drawing.Size(100, 20);
            this.textDay.TabIndex = 7;
            // 
            // textPlace
            // 
            this.textPlace.Location = new System.Drawing.Point(769, 113);
            this.textPlace.Name = "textPlace";
            this.textPlace.Size = new System.Drawing.Size(100, 20);
            this.textPlace.TabIndex = 8;
            this.textPlace.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // fromHour
            // 
            this.fromHour.FormattingEnabled = true;
            this.fromHour.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.fromHour.Location = new System.Drawing.Point(189, 113);
            this.fromHour.Name = "fromHour";
            this.fromHour.Size = new System.Drawing.Size(54, 21);
            this.fromHour.TabIndex = 2;
            // 
            // fromMin
            // 
            this.fromMin.FormattingEnabled = true;
            this.fromMin.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.fromMin.Location = new System.Drawing.Point(267, 113);
            this.fromMin.Name = "fromMin";
            this.fromMin.Size = new System.Drawing.Size(54, 21);
            this.fromMin.TabIndex = 3;
            // 
            // toHour
            // 
            this.toHour.FormattingEnabled = true;
            this.toHour.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.toHour.Location = new System.Drawing.Point(351, 113);
            this.toHour.Name = "toHour";
            this.toHour.Size = new System.Drawing.Size(54, 21);
            this.toHour.TabIndex = 4;
            // 
            // toMin
            // 
            this.toMin.FormattingEnabled = true;
            this.toMin.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.toMin.Location = new System.Drawing.Point(423, 113);
            this.toMin.Name = "toMin";
            this.toMin.Size = new System.Drawing.Size(54, 21);
            this.toMin.TabIndex = 5;
            // 
            // ampm
            // 
            this.ampm.FormattingEnabled = true;
            this.ampm.Items.AddRange(new object[] {
            "A.M.",
            "P.M."});
            this.ampm.Location = new System.Drawing.Point(521, 113);
            this.ampm.Name = "ampm";
            this.ampm.Size = new System.Drawing.Size(50, 21);
            this.ampm.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(251, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = ":";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(410, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = ":";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(189, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(507, 74);
            this.button1.TabIndex = 18;
            this.button1.TabStop = false;
            this.button1.Text = "Generate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(410, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = ":";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(251, 155);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = ":";
            // 
            // ampm2
            // 
            this.ampm2.FormattingEnabled = true;
            this.ampm2.Items.AddRange(new object[] {
            "A.M.",
            "P.M."});
            this.ampm2.Location = new System.Drawing.Point(521, 151);
            this.ampm2.Name = "ampm2";
            this.ampm2.Size = new System.Drawing.Size(50, 21);
            this.ampm2.TabIndex = 24;
            // 
            // toMin2
            // 
            this.toMin2.FormattingEnabled = true;
            this.toMin2.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.toMin2.Location = new System.Drawing.Point(423, 151);
            this.toMin2.Name = "toMin2";
            this.toMin2.Size = new System.Drawing.Size(54, 21);
            this.toMin2.TabIndex = 23;
            // 
            // toHour2
            // 
            this.toHour2.FormattingEnabled = true;
            this.toHour2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.toHour2.Location = new System.Drawing.Point(351, 151);
            this.toHour2.Name = "toHour2";
            this.toHour2.Size = new System.Drawing.Size(54, 21);
            this.toHour2.TabIndex = 22;
            // 
            // fromMin2
            // 
            this.fromMin2.FormattingEnabled = true;
            this.fromMin2.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.fromMin2.Location = new System.Drawing.Point(267, 151);
            this.fromMin2.Name = "fromMin2";
            this.fromMin2.Size = new System.Drawing.Size(54, 21);
            this.fromMin2.TabIndex = 21;
            // 
            // fromHour2
            // 
            this.fromHour2.FormattingEnabled = true;
            this.fromHour2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.fromHour2.Location = new System.Drawing.Point(189, 151);
            this.fromHour2.Name = "fromHour2";
            this.fromHour2.Size = new System.Drawing.Size(54, 21);
            this.fromHour2.TabIndex = 20;
            // 
            // textPlace2
            // 
            this.textPlace2.Location = new System.Drawing.Point(769, 151);
            this.textPlace2.Name = "textPlace2";
            this.textPlace2.Size = new System.Drawing.Size(100, 20);
            this.textPlace2.TabIndex = 26;
            this.textPlace2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textDay2
            // 
            this.textDay2.Location = new System.Drawing.Point(627, 151);
            this.textDay2.Name = "textDay2";
            this.textDay2.Size = new System.Drawing.Size(100, 20);
            this.textDay2.TabIndex = 25;
            // 
            // textClass2
            // 
            this.textClass2.Location = new System.Drawing.Point(23, 151);
            this.textClass2.Name = "textClass2";
            this.textClass2.Size = new System.Drawing.Size(123, 20);
            this.textClass2.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(410, 195);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 13);
            this.label11.TabIndex = 38;
            this.label11.Text = ":";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(251, 195);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 13);
            this.label12.TabIndex = 37;
            this.label12.Text = ":";
            // 
            // ampm3
            // 
            this.ampm3.FormattingEnabled = true;
            this.ampm3.Items.AddRange(new object[] {
            "A.M.",
            "P.M."});
            this.ampm3.Location = new System.Drawing.Point(521, 191);
            this.ampm3.Name = "ampm3";
            this.ampm3.Size = new System.Drawing.Size(50, 21);
            this.ampm3.TabIndex = 34;
            // 
            // toMin3
            // 
            this.toMin3.FormattingEnabled = true;
            this.toMin3.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.toMin3.Location = new System.Drawing.Point(423, 191);
            this.toMin3.Name = "toMin3";
            this.toMin3.Size = new System.Drawing.Size(54, 21);
            this.toMin3.TabIndex = 33;
            // 
            // toHour3
            // 
            this.toHour3.FormattingEnabled = true;
            this.toHour3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.toHour3.Location = new System.Drawing.Point(351, 191);
            this.toHour3.Name = "toHour3";
            this.toHour3.Size = new System.Drawing.Size(54, 21);
            this.toHour3.TabIndex = 32;
            // 
            // fromMin3
            // 
            this.fromMin3.FormattingEnabled = true;
            this.fromMin3.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.fromMin3.Location = new System.Drawing.Point(267, 191);
            this.fromMin3.Name = "fromMin3";
            this.fromMin3.Size = new System.Drawing.Size(54, 21);
            this.fromMin3.TabIndex = 31;
            // 
            // fromHour3
            // 
            this.fromHour3.FormattingEnabled = true;
            this.fromHour3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.fromHour3.Location = new System.Drawing.Point(189, 191);
            this.fromHour3.Name = "fromHour3";
            this.fromHour3.Size = new System.Drawing.Size(54, 21);
            this.fromHour3.TabIndex = 30;
            // 
            // textPlace3
            // 
            this.textPlace3.Location = new System.Drawing.Point(769, 191);
            this.textPlace3.Name = "textPlace3";
            this.textPlace3.Size = new System.Drawing.Size(100, 20);
            this.textPlace3.TabIndex = 36;
            this.textPlace3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textDay3
            // 
            this.textDay3.Location = new System.Drawing.Point(627, 191);
            this.textDay3.Name = "textDay3";
            this.textDay3.Size = new System.Drawing.Size(100, 20);
            this.textDay3.TabIndex = 35;
            // 
            // textClass3
            // 
            this.textClass3.Location = new System.Drawing.Point(23, 191);
            this.textClass3.Name = "textClass3";
            this.textClass3.Size = new System.Drawing.Size(123, 20);
            this.textClass3.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(410, 230);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 13);
            this.label13.TabIndex = 48;
            this.label13.Text = ":";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(251, 230);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(10, 13);
            this.label14.TabIndex = 47;
            this.label14.Text = ":";
            // 
            // ampm4
            // 
            this.ampm4.FormattingEnabled = true;
            this.ampm4.Items.AddRange(new object[] {
            "A.M.",
            "P.M."});
            this.ampm4.Location = new System.Drawing.Point(521, 226);
            this.ampm4.Name = "ampm4";
            this.ampm4.Size = new System.Drawing.Size(50, 21);
            this.ampm4.TabIndex = 44;
            // 
            // toMin4
            // 
            this.toMin4.FormattingEnabled = true;
            this.toMin4.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.toMin4.Location = new System.Drawing.Point(423, 226);
            this.toMin4.Name = "toMin4";
            this.toMin4.Size = new System.Drawing.Size(54, 21);
            this.toMin4.TabIndex = 43;
            // 
            // toHour4
            // 
            this.toHour4.FormattingEnabled = true;
            this.toHour4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.toHour4.Location = new System.Drawing.Point(351, 226);
            this.toHour4.Name = "toHour4";
            this.toHour4.Size = new System.Drawing.Size(54, 21);
            this.toHour4.TabIndex = 42;
            // 
            // fromMin4
            // 
            this.fromMin4.FormattingEnabled = true;
            this.fromMin4.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55",
            "60"});
            this.fromMin4.Location = new System.Drawing.Point(267, 226);
            this.fromMin4.Name = "fromMin4";
            this.fromMin4.Size = new System.Drawing.Size(54, 21);
            this.fromMin4.TabIndex = 41;
            // 
            // fromHour4
            // 
            this.fromHour4.FormattingEnabled = true;
            this.fromHour4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.fromHour4.Location = new System.Drawing.Point(189, 226);
            this.fromHour4.Name = "fromHour4";
            this.fromHour4.Size = new System.Drawing.Size(54, 21);
            this.fromHour4.TabIndex = 40;
            // 
            // textPlace4
            // 
            this.textPlace4.Location = new System.Drawing.Point(769, 226);
            this.textPlace4.Name = "textPlace4";
            this.textPlace4.Size = new System.Drawing.Size(100, 20);
            this.textPlace4.TabIndex = 46;
            this.textPlace4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textDay4
            // 
            this.textDay4.Location = new System.Drawing.Point(627, 226);
            this.textDay4.Name = "textDay4";
            this.textDay4.Size = new System.Drawing.Size(100, 20);
            this.textDay4.TabIndex = 45;
            // 
            // textClass4
            // 
            this.textClass4.Location = new System.Drawing.Point(23, 226);
            this.textClass4.Name = "textClass4";
            this.textClass4.Size = new System.Drawing.Size(123, 20);
            this.textClass4.TabIndex = 39;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.fillDataToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(903, 24);
            this.menuStrip1.TabIndex = 49;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked_1);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // fillDataToolStripMenuItem
            // 
            this.fillDataToolStripMenuItem.Name = "fillDataToolStripMenuItem";
            this.fillDataToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.fillDataToolStripMenuItem.Text = "Test Me";
            this.fillDataToolStripMenuItem.Click += new System.EventHandler(this.fillDataToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(903, 359);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.ampm4);
            this.Controls.Add(this.toMin4);
            this.Controls.Add(this.toHour4);
            this.Controls.Add(this.fromMin4);
            this.Controls.Add(this.fromHour4);
            this.Controls.Add(this.textPlace4);
            this.Controls.Add(this.textDay4);
            this.Controls.Add(this.textClass4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.ampm3);
            this.Controls.Add(this.toMin3);
            this.Controls.Add(this.toHour3);
            this.Controls.Add(this.fromMin3);
            this.Controls.Add(this.fromHour3);
            this.Controls.Add(this.textPlace3);
            this.Controls.Add(this.textDay3);
            this.Controls.Add(this.textClass3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ampm2);
            this.Controls.Add(this.toMin2);
            this.Controls.Add(this.toHour2);
            this.Controls.Add(this.fromMin2);
            this.Controls.Add(this.fromHour2);
            this.Controls.Add(this.textPlace2);
            this.Controls.Add(this.textDay2);
            this.Controls.Add(this.textClass2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ampm);
            this.Controls.Add(this.toMin);
            this.Controls.Add(this.toHour);
            this.Controls.Add(this.fromMin);
            this.Controls.Add(this.fromHour);
            this.Controls.Add(this.textPlace);
            this.Controls.Add(this.textDay);
            this.Controls.Add(this.textClass);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Schedulizer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textClass;
        private System.Windows.Forms.TextBox textDay;
        private System.Windows.Forms.TextBox textPlace;
        private System.Windows.Forms.ComboBox fromHour;
        private System.Windows.Forms.ComboBox fromMin;
        private System.Windows.Forms.ComboBox toHour;
        private System.Windows.Forms.ComboBox toMin;
        private System.Windows.Forms.ComboBox ampm;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox ampm2;
        private System.Windows.Forms.ComboBox toMin2;
        private System.Windows.Forms.ComboBox toHour2;
        private System.Windows.Forms.ComboBox fromMin2;
        private System.Windows.Forms.ComboBox fromHour2;
        private System.Windows.Forms.TextBox textPlace2;
        private System.Windows.Forms.TextBox textDay2;
        private System.Windows.Forms.TextBox textClass2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ampm3;
        private System.Windows.Forms.ComboBox toMin3;
        private System.Windows.Forms.ComboBox toHour3;
        private System.Windows.Forms.ComboBox fromMin3;
        private System.Windows.Forms.ComboBox fromHour3;
        private System.Windows.Forms.TextBox textPlace3;
        private System.Windows.Forms.TextBox textDay3;
        private System.Windows.Forms.TextBox textClass3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox ampm4;
        private System.Windows.Forms.ComboBox toMin4;
        private System.Windows.Forms.ComboBox toHour4;
        private System.Windows.Forms.ComboBox fromMin4;
        private System.Windows.Forms.ComboBox fromHour4;
        private System.Windows.Forms.TextBox textPlace4;
        private System.Windows.Forms.TextBox textDay4;
        private System.Windows.Forms.TextBox textClass4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fillDataToolStripMenuItem;
    }
}

