﻿namespace Schedule_Generator
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.takeSnapShotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox1111 = new System.Windows.Forms.TextBox();
            this.textBox2222 = new System.Windows.Forms.TextBox();
            this.textBox222 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3333 = new System.Windows.Forms.TextBox();
            this.textBox333 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4444 = new System.Windows.Forms.TextBox();
            this.textBox444 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5555 = new System.Windows.Forms.TextBox();
            this.textBox555 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.DarkRed;
            this.label5.Name = "label5";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.takeSnapShotToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            resources.ApplyResources(this.toolStripMenuItem1, "toolStripMenuItem1");
            // 
            // takeSnapShotToolStripMenuItem
            // 
            this.takeSnapShotToolStripMenuItem.Name = "takeSnapShotToolStripMenuItem";
            resources.ApplyResources(this.takeSnapShotToolStripMenuItem, "takeSnapShotToolStripMenuItem");
            this.takeSnapShotToolStripMenuItem.Click += new System.EventHandler(this.takeSnapShotToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "bmp";
            this.saveFileDialog1.FileName = "MySchedule";
            resources.ApplyResources(this.saveFileDialog1, "saveFileDialog1");
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.ForeColor = System.Drawing.Color.Blue;
            this.textBox1.Name = "textBox1";
            this.textBox1.TabStop = false;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.White;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox11, "textBox11");
            this.textBox11.ForeColor = System.Drawing.Color.Blue;
            this.textBox11.Name = "textBox11";
            this.textBox11.TabStop = false;
            // 
            // textBox111
            // 
            this.textBox111.BackColor = System.Drawing.Color.White;
            this.textBox111.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox111, "textBox111");
            this.textBox111.ForeColor = System.Drawing.Color.Blue;
            this.textBox111.Name = "textBox111";
            this.textBox111.TabStop = false;
            // 
            // textBox1111
            // 
            this.textBox1111.BackColor = System.Drawing.Color.White;
            this.textBox1111.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox1111, "textBox1111");
            this.textBox1111.ForeColor = System.Drawing.Color.Blue;
            this.textBox1111.Name = "textBox1111";
            this.textBox1111.TabStop = false;
            // 
            // textBox2222
            // 
            this.textBox2222.BackColor = System.Drawing.Color.White;
            this.textBox2222.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox2222, "textBox2222");
            this.textBox2222.ForeColor = System.Drawing.Color.Blue;
            this.textBox2222.Name = "textBox2222";
            this.textBox2222.TabStop = false;
            // 
            // textBox222
            // 
            this.textBox222.BackColor = System.Drawing.Color.White;
            this.textBox222.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox222, "textBox222");
            this.textBox222.ForeColor = System.Drawing.Color.Blue;
            this.textBox222.Name = "textBox222";
            this.textBox222.TabStop = false;
            // 
            // textBox22
            // 
            this.textBox22.BackColor = System.Drawing.Color.White;
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox22, "textBox22");
            this.textBox22.ForeColor = System.Drawing.Color.Blue;
            this.textBox22.Name = "textBox22";
            this.textBox22.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.ForeColor = System.Drawing.Color.Blue;
            this.textBox2.Name = "textBox2";
            this.textBox2.TabStop = false;
            // 
            // textBox3333
            // 
            this.textBox3333.BackColor = System.Drawing.Color.White;
            this.textBox3333.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox3333, "textBox3333");
            this.textBox3333.ForeColor = System.Drawing.Color.Blue;
            this.textBox3333.Name = "textBox3333";
            this.textBox3333.TabStop = false;
            // 
            // textBox333
            // 
            this.textBox333.BackColor = System.Drawing.Color.White;
            this.textBox333.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox333, "textBox333");
            this.textBox333.ForeColor = System.Drawing.Color.Blue;
            this.textBox333.Name = "textBox333";
            this.textBox333.TabStop = false;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.Color.White;
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox33, "textBox33");
            this.textBox33.ForeColor = System.Drawing.Color.Blue;
            this.textBox33.Name = "textBox33";
            this.textBox33.TabStop = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.ForeColor = System.Drawing.Color.Blue;
            this.textBox3.Name = "textBox3";
            this.textBox3.TabStop = false;
            // 
            // textBox4444
            // 
            this.textBox4444.BackColor = System.Drawing.Color.White;
            this.textBox4444.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox4444, "textBox4444");
            this.textBox4444.ForeColor = System.Drawing.Color.Blue;
            this.textBox4444.Name = "textBox4444";
            this.textBox4444.TabStop = false;
            // 
            // textBox444
            // 
            this.textBox444.BackColor = System.Drawing.Color.White;
            this.textBox444.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox444, "textBox444");
            this.textBox444.ForeColor = System.Drawing.Color.Blue;
            this.textBox444.Name = "textBox444";
            this.textBox444.TabStop = false;
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.Color.White;
            this.textBox44.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox44, "textBox44");
            this.textBox44.ForeColor = System.Drawing.Color.Blue;
            this.textBox44.Name = "textBox44";
            this.textBox44.TabStop = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.ForeColor = System.Drawing.Color.Blue;
            this.textBox4.Name = "textBox4";
            this.textBox4.TabStop = false;
            // 
            // textBox5555
            // 
            this.textBox5555.BackColor = System.Drawing.Color.White;
            this.textBox5555.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox5555, "textBox5555");
            this.textBox5555.ForeColor = System.Drawing.Color.Blue;
            this.textBox5555.Name = "textBox5555";
            this.textBox5555.TabStop = false;
            // 
            // textBox555
            // 
            this.textBox555.BackColor = System.Drawing.Color.White;
            this.textBox555.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox555, "textBox555");
            this.textBox555.ForeColor = System.Drawing.Color.Blue;
            this.textBox555.Name = "textBox555";
            this.textBox555.TabStop = false;
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.Color.White;
            this.textBox55.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox55, "textBox55");
            this.textBox55.ForeColor = System.Drawing.Color.Blue;
            this.textBox55.Name = "textBox55";
            this.textBox55.TabStop = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.ForeColor = System.Drawing.Color.Blue;
            this.textBox5.Name = "textBox5";
            this.textBox5.TabStop = false;
            // 
            // Form2
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.textBox5555);
            this.Controls.Add(this.textBox555);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4444);
            this.Controls.Add(this.textBox444);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3333);
            this.Controls.Add(this.textBox333);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2222);
            this.Controls.Add(this.textBox222);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1111);
            this.Controls.Add(this.textBox111);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem takeSnapShotToolStripMenuItem;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox11;
        public System.Windows.Forms.TextBox textBox111;
        public System.Windows.Forms.TextBox textBox1111;
        public System.Windows.Forms.TextBox textBox2222;
        public System.Windows.Forms.TextBox textBox222;
        public System.Windows.Forms.TextBox textBox22;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox3333;
        public System.Windows.Forms.TextBox textBox333;
        public System.Windows.Forms.TextBox textBox33;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox4444;
        public System.Windows.Forms.TextBox textBox444;
        public System.Windows.Forms.TextBox textBox44;
        public System.Windows.Forms.TextBox textBox4;
        public System.Windows.Forms.TextBox textBox5555;
        public System.Windows.Forms.TextBox textBox555;
        public System.Windows.Forms.TextBox textBox55;
        public System.Windows.Forms.TextBox textBox5;

    }
}